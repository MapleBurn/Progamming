using System.ComponentModel.DataAnnotations;

namespace BankApp.Models;

public class Credentials
{
    [Required]
    public string UserName { get; set; }
    [Required]
    public string Password { get; set; }
}