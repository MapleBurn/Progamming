using System.Text.Json;
using BankApp.Models;
using Microsoft.AspNetCore.Http.HttpResults;

namespace BankApp.Services;

public class UserService
{
    public static async Task<List<Credentials>> GetAllUsersAsync()
    {
        var users = await JsonSerializer.DeserializeAsync<List<Credentials>>(File.OpenRead("Data/Users.json"));
        return users;
    }
    public static async void AddNewUserAsync(Credentials credentials, List<Credentials> users)
    {
        // Create the new user
        var newUser = new Credentials()
        {
            UserName = credentials.UserName,
            Password = credentials.Password
        };
        
        users.Add(newUser);
        
        using var fs = new FileStream("Data/Users.json", FileMode.Create);
        var options = new JsonSerializerOptions { WriteIndented = true };
        await JsonSerializer.SerializeAsync(fs, users, options);
    }
    public static async void SetAllUsersAsync(List<Credentials> users)
    {
        using var fs = new FileStream("Data/Users.json", FileMode.Create);
        var options = new JsonSerializerOptions { WriteIndented = true };
        await JsonSerializer.SerializeAsync(fs, users, options);
    }
}