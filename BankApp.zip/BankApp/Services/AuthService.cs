using BankApp.Models;

namespace BankApp.Services;

public class AuthService
{
    public bool IsLoggedIn { get; private set; } = false;
    public string CurrentUser { get; private set; }

    public event Action OnChange;

    public async Task<bool> Login(Credentials credentials)
    {
        var users = await UserService.GetAllUsersAsync();
        
        if (users.Any(u => u.UserName == credentials.UserName && u.Password == credentials.Password))
        {
            IsLoggedIn = true;
            CurrentUser = credentials.UserName;
            NotifyStateChanged();
            return true;
        }

        return false;
    }


    public void Logout()
    {
        IsLoggedIn = false;
        CurrentUser = null;
        NotifyStateChanged();
    }

    private void NotifyStateChanged() => OnChange?.Invoke();
}